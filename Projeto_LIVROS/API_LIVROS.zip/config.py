import os.path

SECRET_KEY = "dezembro_de_81"
DEBUG = True

DB_HOST = 'localhost'
DB_NAME = r'C:\Users\Aluno\Desktop\ApiJoao\Banco\BANCO.FDB'


DB_USER = 'sysdba'
DB_PASSWORD = 'sysdba'

UPLOAD_FOLDER = os.path.abspath(os.path.dirname(__file__))