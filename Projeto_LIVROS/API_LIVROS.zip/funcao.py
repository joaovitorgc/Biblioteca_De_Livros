from flask_bcrypt import generate_password_hash, check_password_hash
import smtplib
from main import app
from email.mime.text import MIMEText

import jwt
import datetime

def validar_senha(senha: str):
    if not senha:
        return False

    maiuscula = minuscula = numero = especial = False

    for s in senha:
        if s.isupper():
            maiuscula = True
        elif s.islower():
            minuscula = True
        elif s.isdigit():
            numero = True
        elif not s.isalnum():
            especial = True

    if len(senha) < 8 or len(senha) > 12:
        return False

    if not (maiuscula and minuscula and numero and especial):
        return False
    return True

def enviando_email(destinatario, assunto, mensagem):
    user = "sophia.biliattoo@gmail.com"
    senha = "eahu tqrv kaxi jsnb"

    msg = MIMEText(mensagem)
    msg['Subject'] = assunto
    msg['From'] = user
    msg['To'] = destinatario

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(user, senha)
    server.send_message(msg)
    server.quit()

def gerar_token(id_usuario):
    pyload = {
        'id_usuario':id_usuario,
        'timestamp': datetime.datetime.utcnow().isoformat()
    }
    token = jwt.encode(pyload, app.config['SECRET_KEY'], algorithm='HS256')
    return token

def remover_bearer(token):
    if token.startswith('Bearer '):
        return token[len('Bearer '):]
    else:
        return token

